﻿partial class MuqadasKhalidForm // Updated class name
{
    private System.Windows.Forms.TextBox txt_courseCode; // Changed to reflect course information
    private System.Windows.Forms.TextBox txt_courseTitle;
    private System.Windows.Forms.TextBox txt_obtainedMarks;
    private System.Windows.Forms.TextBox txt_grade;
    private System.Windows.Forms.TextBox txt_status;
    private System.Windows.Forms.Button btn_add;
    private System.Windows.Forms.DataGridView dataGridView1;

    private System.Windows.Forms.Label lbl_courseCode;
    private System.Windows.Forms.Label lbl_courseTitle;
    private System.Windows.Forms.Label lbl_obtainedMarks;
    private System.Windows.Forms.Label lbl_grade;
    private System.Windows.Forms.Label lbl_status;

    private void InitializeComponent()
    {
        this.txt_courseCode = new System.Windows.Forms.TextBox();
        this.txt_courseTitle = new System.Windows.Forms.TextBox();
        this.txt_obtainedMarks = new System.Windows.Forms.TextBox();
        this.txt_grade = new System.Windows.Forms.TextBox();
        this.txt_status = new System.Windows.Forms.TextBox();
        this.btn_add = new System.Windows.Forms.Button();
        this.dataGridView1 = new System.Windows.Forms.DataGridView();

        this.lbl_courseCode = new System.Windows.Forms.Label();
        this.lbl_courseTitle = new System.Windows.Forms.Label();
        this.lbl_obtainedMarks = new System.Windows.Forms.Label();
        this.lbl_grade = new System.Windows.Forms.Label();
        this.lbl_status = new System.Windows.Forms.Label();

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
        this.SuspendLayout();

        // txt_courseCode
        this.txt_courseCode.Location = new System.Drawing.Point(150, 20);
        this.txt_courseCode.Name = "txt_courseCode";
        this.txt_courseCode.Size = new System.Drawing.Size(100, 20);
        this.txt_courseCode.TabIndex = 0;

        // lbl_courseCode
        this.lbl_courseCode.AutoSize = true;
        this.lbl_courseCode.Location = new System.Drawing.Point(20, 20);
        this.lbl_courseCode.Name = "lbl_courseCode";
        this.lbl_courseCode.Size = new System.Drawing.Size(71, 13);
        this.lbl_courseCode.TabIndex = 7;
        this.lbl_courseCode.Text = "Course Code:";

        // txt_courseTitle
        this.txt_courseTitle.Location = new System.Drawing.Point(150, 50);
        this.txt_courseTitle.Name = "txt_courseTitle";
        this.txt_courseTitle.Size = new System.Drawing.Size(100, 20);
        this.txt_courseTitle.TabIndex = 1;

        // lbl_courseTitle
        this.lbl_courseTitle.AutoSize = true;
        this.lbl_courseTitle.Location = new System.Drawing.Point(20, 50);
        this.lbl_courseTitle.Name = "lbl_courseTitle";
        this.lbl_courseTitle.Size = new System.Drawing.Size(69, 13);
        this.lbl_courseTitle.TabIndex = 8;
        this.lbl_courseTitle.Text = "Course Title:";

        // txt_obtainedMarks
        this.txt_obtainedMarks.Location = new System.Drawing.Point(150, 80);
        this.txt_obtainedMarks.Name = "txt_obtainedMarks";
        this.txt_obtainedMarks.Size = new System.Drawing.Size(100, 20);
        this.txt_obtainedMarks.TabIndex = 2;

        // lbl_obtainedMarks
        this.lbl_obtainedMarks.AutoSize = true;
        this.lbl_obtainedMarks.Location = new System.Drawing.Point(20, 80);
        this.lbl_obtainedMarks.Name = "lbl_obtainedMarks";
        this.lbl_obtainedMarks.Size = new System.Drawing.Size(90, 13);
        this.lbl_obtainedMarks.TabIndex = 9;
        this.lbl_obtainedMarks.Text = "Obtained Marks:";

        // txt_grade
        this.txt_grade.Location = new System.Drawing.Point(150, 110);
        this.txt_grade.Name = "txt_grade";
        this.txt_grade.Size = new System.Drawing.Size(100, 20);
        this.txt_grade.TabIndex = 3;

        // lbl_grade
        this.lbl_grade.AutoSize = true;
        this.lbl_grade.Location = new System.Drawing.Point(20, 110);
        this.lbl_grade.Name = "lbl_grade";
        this.lbl_grade.Size = new System.Drawing.Size(39, 13);
        this.lbl_grade.TabIndex = 10;
        this.lbl_grade.Text = "Grade:";

        // txt_status
        this.txt_status.Location = new System.Drawing.Point(150, 140);
        this.txt_status.Name = "txt_status";
        this.txt_status.Size = new System.Drawing.Size(100, 20);
        this.txt_status.TabIndex = 4;

        // lbl_status
        this.lbl_status.AutoSize = true;
        this.lbl_status.Location = new System.Drawing.Point(20, 140);
        this.lbl_status.Name = "lbl_status";
        this.lbl_status.Size = new System.Drawing.Size(43, 13);
        this.lbl_status.TabIndex = 11;
        this.lbl_status.Text = "Status:";

        // btn_add
        this.btn_add.Location = new System.Drawing.Point(150, 170);
        this.btn_add.Name = "btn_add";
        this.btn_add.Size = new System.Drawing.Size(100, 30);
        this.btn_add.TabIndex = 5;
        this.btn_add.Text = "Add Data";
        this.btn_add.UseVisualStyleBackColor = true;
        this.btn_add.Click += new System.EventHandler(this.btn_add_Click);

        // dataGridView1
        this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridView1.Location = new System.Drawing.Point(300, 20);
        this.dataGridView1.Name = "dataGridView1";
        this.dataGridView1.Size = new System.Drawing.Size(400, 180);
        this.dataGridView1.TabIndex = 6;

        // MuqadasKhalidForm
        this.ClientSize = new System.Drawing.Size(800, 250);
        this.Controls.Add(this.lbl_courseCode);
        this.Controls.Add(this.lbl_courseTitle);
        this.Controls.Add(this.lbl_obtainedMarks);
        this.Controls.Add(this.lbl_grade);
        this.Controls.Add(this.lbl_status);
        this.Controls.Add(this.txt_courseCode);
        this.Controls.Add(this.txt_courseTitle);
        this.Controls.Add(this.txt_obtainedMarks);
        this.Controls.Add(this.txt_grade);
        this.Controls.Add(this.txt_status);
        this.Controls.Add(this.btn_add);
        this.Controls.Add(this.dataGridView1);
        this.Name = "MuqadasKhalidForm";
        this.Text = "Muqadas Khalid's Course Information";

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }
}
