namespace Muqadas_s_Table
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MuqadasKhalidForm()); // Updated to reference the correct form
        }
    }
}
